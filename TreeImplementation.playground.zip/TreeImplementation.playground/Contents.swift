import UIKit

struct Queue<Elements>{
    
    var element:[Elements] = []
    
    @discardableResult
    mutating func enque(_value:Elements) -> Bool {
        element.append(_value)
        return true
    }
    
    var isEmpty:Bool{
        return element.isEmpty
    }
    mutating func deque() -> Elements? {
        return isEmpty ? nil : element.removeFirst()
    }
    init(){
    }
}

class TreeNode<T> {
    var value : T
    var childNode : [TreeNode] = []
    
    init(value:  T) {
        self.value = value
    }
    
    func add(_ child: TreeNode){
        self.childNode.append(child)
    }
}

extension TreeNode where T: Equatable{
    
    func forEachDepthFirst(_ visit :(TreeNode)->Void){
        visit(self)
        childNode.forEach{
            $0.forEachDepthFirst(visit)
        }
    }
    
    func forEachLevelOrder(_ visit:(TreeNode)-> Void){
        visit(self)
        var que = Queue<TreeNode>()
        childNode.forEach{
            _ = que.enque(_value: $0)
        }
        while let node = que.deque(){
            visit(node)
            node.childNode.forEach{
                _ = que.enque(_value: $0)
            }
        }
    }
    func search(_ value: T)-> TreeNode?{
        var result:TreeNode?
        
        forEachLevelOrder { node in
            if node.value == value{
                result = node
            }
        }
        return result
    }
}

let beverages = TreeNode<String>(value: "Beverages")
let hot = TreeNode<String>(value: "Hot")
let cold = TreeNode<String>(value: "Cold")
beverages.add(hot)
beverages.add(cold)
let tea = TreeNode<String>(value: "tea")
let cofee = TreeNode<String>(value: "cofee")
hot.add(tea)
hot.add(cofee)

let milk = TreeNode<String>(value: "milk")
let juice = TreeNode<String>(value: "juice")
cold.add(milk)
cold.add(juice)
//beverages.forEachDepthFirst{
//    print($0.value)
//}


//beverages.forEachLevelOrder{
//    print($0.value)
//}

print(beverages.search("apple")?.value ?? "")
