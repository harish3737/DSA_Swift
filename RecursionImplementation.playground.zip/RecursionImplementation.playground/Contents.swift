import UIKit


func factorial(number: Int) -> Int{
    
    if number == 0{
        return 1
    }
    return number * factorial(number: number - 1)
}

print(factorial(number: 5))



func powerCalculation(number : Int,power: Int) -> Int{
    if power == 0 {
        return 1
    }else{
        return number * powerCalculation(number: number, power: power - 1)
    }
}

print(powerCalculation(number: 2, power: 5))
