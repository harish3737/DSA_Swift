import UIKit

struct Stack<Element>{
    private var storage:[Element] = []
    
    mutating func push(_ element:Element){
        storage.append(element)
    }
    
    mutating func pop() -> Element?{
        return storage.popLast()
    }
    
    init() {}
}

extension Stack : CustomStringConvertible {
    
    var description : String{
        let topDivider = "---------top---------\n"
        let bottomDivider = "\n----------------"
        
        let stackElements = storage.map {"\($0)"}.reversed().joined(separator: "\n")
        return topDivider + stackElements + bottomDivider
    }
}


var stack = Stack<Int>()
stack.push(20)
stack.push(30)
print(stack)
stack.pop()
stack.push(50)
print(stack)
stack.pop()
print(stack)
