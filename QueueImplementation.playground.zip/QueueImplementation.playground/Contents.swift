import UIKit

struct Queue<T> {
    
    var queue:[T] = []
    
    
    init(){}
    
    mutating func enqueueOperation(value:T) -> Bool{
        queue.append(value)
        return true
    }
    
    mutating func dequeueOperation() -> T?{
        return isEmpty ? nil : queue.removeFirst()
    }
    
    var isEmpty:Bool{
        return queue.isEmpty
    }
    
    var peek : T?{
        return queue.first
    }
}



var queueOperand = Queue<Int>()
queueOperand.enqueueOperation(value: 10)
queueOperand.enqueueOperation(value: 30)
queueOperand.enqueueOperation(value: 50)
print(queueOperand)
queueOperand.dequeueOperation()
print(queueOperand)
