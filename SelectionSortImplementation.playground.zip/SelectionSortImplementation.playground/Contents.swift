import UIKit

var numbers = [2,6,7,19,11,45,9,23,56,78,29]

print("Array before sorting",numbers)

var minIndex = 0

for i in 0..<numbers.count{
    minIndex = i
    for j in (i+1)..<numbers.count{
        
        if numbers[j]<numbers[minIndex]{
            minIndex = j
        }
        //swap the values
        numbers.swapAt(i, minIndex)
    }
}

print("Numbers after sorting",numbers)
