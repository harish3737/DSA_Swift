import UIKit

var numbers = [2,6,7,19,11,45,9,23,56,78,9]
print("Array before Sorted",numbers)

for i in 0..<numbers.count{
    
    for j in 0..<numbers.count{
        
        if(numbers[i]<numbers[j]){
            numbers.swapAt(i, j)
        }
    }
}
print("After Swap",numbers)
